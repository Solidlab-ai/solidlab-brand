# Solidlab Brand Assets

Official Solidlab logo pack — v1.1 Nordic
April 2026

## Contents

### /svg — Vector formats
Outlined SVG — Geist Bold glyphs converted to paths.
No font dependency. Use these for:
- Web (hero, nav, footer)
- Print (unlimited scale)
- Professional design tools (Figma, Sketch, Illustrator)

### /png — Raster formats
PNG at 1x, @2x, @4x.
Use these for:
- Word, Google Docs, PowerPoint
- Email signatures (@1x)
- Retina displays (@2x)
- Print-resolution (@4x)

### /guidelines
Full brand guidelines PDF (v1.1 Nordic).

## Logo variants

| File | Usage |
|---|---|
| `solidlab-logo-sort-on-antikkhvit` | Primary — dark on light |
| `solidlab-logo-antikkhvit-on-sort` | Reversed — light on dark |
| `solidlab-logo-antikkhvit-on-oslo` | Brand — Oslo blue background |
| `solidlab-monogram-sl-sort` | Compact — for favicons, app icons, stamps |

## Colors

- Oslo: `#4A5A62`
- Sort: `#0A0A0A`
- Antikkhvit: `#F4F1EA`

## Contact
privacy@solidlab.ai — for permission questions
hello@solidlab.ai — for partnerships

© 2026 Stå på Pinne AS — Solidlab is a trading name
