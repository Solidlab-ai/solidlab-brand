# Solidlab Brand Assets — v2 (correct wordmark)

Official Solidlab logo pack.
April 2026

## The core logo

The Solidlab wordmark uses Geist in **two weights**:
- **solid** — Geist Bold (700), tracking -0.02em
- **lab** — Geist Regular (400)
- **.ai** — Geist Regular (400) in Oslo blue (#4A5A62) — optional

The weight contrast between `solid` and `lab` IS the logo.
No symbol. No monogram. No decoration.

## Contents

### /svg — Vector formats (outlined, no font dependency)
- `solidlab-wordmark-oslo-ai-on-antikkhvit.svg` — primary with .ai in Oslo blue
- `solidlab-wordmark-oslo-ai-on-sort.svg` — dark mode variant
- `solidlab-wordmark-on-antikkhvit.svg` — wordmark only, light
- `solidlab-wordmark-on-sort.svg` — wordmark only, dark
- `solidlab-wordmark-on-oslo.svg` — wordmark on Oslo blue
- `solidlab-favicon-s-on-sort.svg` — favicon: heavy "s" glyph
- `solidlab-favicon-s-on-antikkhvit.svg` — favicon light variant

### /png — Raster formats (1x, @2x, @4x)
Same variants. Use @2x for retina screens, @4x for print.

### /guidelines
See: https://brand.solidlab.ai/assets/solidlab-brand-guidelines-v1.1-nordic.pdf

## Colors

- **Oslo** `#4A5A62` — brand accent, used sparingly like good paint
- **Sort** `#0A0A0A` — dark backgrounds
- **Antikkhvit** `#F4F1EA` — warm off-white
- **Nordic Breeze** `#6B8290` — .ai treatment on dark backgrounds

## Usage

The wordmark works unadorned at any size from 20px (favicon row) to hero.
Do not:
- Add a symbol next to the wordmark
- Change the weight ratio between `solid` and `lab`
- Re-tint `.ai` to any color other than Oslo or Nordic Breeze
- Stretch, rotate, or add effects

For third-party use, request permission at hello@solidlab.ai.

© 2026 Stå på Pinne AS — Solidlab is a trading name
