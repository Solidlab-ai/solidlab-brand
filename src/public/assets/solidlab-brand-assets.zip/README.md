# Solidlab Brand Assets — v3

Official Solidlab logo pack.
April 2026

## The core logo

The Solidlab wordmark uses Geist in **two weights**:
- **solid** — Geist Bold (700), tracking -0.02em
- **lab** — Geist Regular (400)
- **.ai** — Geist Regular (400) in Oslo blue (#4A5A62)

The weight contrast between `solid` and `lab` IS the logo.

## Two types of files

### With background (solid color)
Use when you need a complete "stamp" with guaranteed legibility:
- `solidlab-wordmark-oslo-ai-on-antikkhvit.*` — primary
- `solidlab-wordmark-oslo-ai-on-sort.*` — dark
- `solidlab-wordmark-on-antikkhvit.*` — wordmark only, light bg
- `solidlab-wordmark-on-sort.*` — wordmark only, dark bg
- `solidlab-wordmark-on-oslo.*` — on Oslo blue
- `solidlab-favicon-s-on-sort.*` — favicon
- `solidlab-favicon-s-on-antikkhvit.*` — favicon light

### Transparent background ★ NEW
Use when placing on photos, images, colored surfaces, or any context
where you don't want a background box:
- `solidlab-wordmark-oslo-ai-dark-transparent.*` — for light/photo bg
- `solidlab-wordmark-oslo-ai-light-transparent.*` — for dark/photo bg
- `solidlab-wordmark-dark-transparent.*` — wordmark only, dark ink
- `solidlab-wordmark-light-transparent.*` — wordmark only, light ink
- `solidlab-wordmark-mono-black-transparent.*` — pure black (print, stamps)
- `solidlab-wordmark-mono-white-transparent.*` — pure white (dark bg)
- `solidlab-favicon-s-dark-transparent.*` — favicon, dark
- `solidlab-favicon-s-light-transparent.*` — favicon, light

## Format notes
- **SVG:** Vector, outlined paths. No font dependency. Use for web, print, any scale.
- **PNG @1x:** 480-640px wide — web use
- **PNG @2x:** retina displays, LinkedIn, Instagram
- **PNG @4x:** print resolution, presentations at large scale

## Colors
- **Oslo** `#4A5A62` — brand accent
- **Sort** `#0A0A0A` — dark backgrounds
- **Antikkhvit** `#F4F1EA` — warm off-white
- **Nordic Breeze** `#6B8290` — .ai on dark backgrounds

## Usage rules
- Do not add a symbol next to the wordmark
- Do not change the weight ratio between `solid` and `lab`
- Do not re-tint `.ai` to any color other than Oslo or Nordic Breeze
- Do not stretch, rotate, or add effects

For third-party use, request permission at hello@solidlab.ai.

© 2026 Stå på Pinne AS — Solidlab is a trading name
